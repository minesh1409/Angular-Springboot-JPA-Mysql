import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {

  model: any = {};

  constructor() { }

  ngOnInit(): void {
  }

  updateUserInfo() {
    console.log("updateUserInfo", this.model);
  }
}
