import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { Employee } from '../../../model/employee'
import { EmployeeService } from '../../../services/employee.service'
import { SubjectMessageService } from '../../../services/subject-message.service'

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  //commented for service
  /* empList:Employee[]=[
    new Employee(1,'jhon','casel break, winterfall',9900878999,new Date(),''),
    new Employee(2,'arya','North, winterfall',9900878988,new Date(),''),
    new Employee(3,'theon','unknown world',9900878977,new Date(),'')
  ] */

  empList: Employee[] = [];

  constructor(private employeeService: EmployeeService,
    private subMsg: SubjectMessageService) { }

  ngOnInit(): void {
    //comment to implement services
    //this.empList = this.employeeService.getEmployeeList();
    /* this.employeeService.getEmployeeList().subscribe((list: Employee[]) => {
      console.log(list);
      return this.empList = list;
    }); */
    this.getEmployees();
    this.subMsg.getMessage().subscribe(
      () => {
        this.getEmployees();
      })
  }

  //for implement subject 
  getEmployees() {
    this.employeeService.getEmployeeList().subscribe((list: Employee[]) => {
      console.log(list);
      return this.empList = list;
    });
  }

  remove(id: number) {
    this.employeeService.removeEmployee(id)
      .subscribe(() => {
        this.subMsg.setMessage({ msg: 'Successfull deleted' });
      },
        (error) => {
          alert("something to be wrong!!!");
        });
  }

  edit(id: number) {
    this.employeeService.getEmployee(id)
      .subscribe((data) => {
        console.log("::::: from list:::::");
        console.log(data);
        this.subMsg.setData(data);
      },
        (error) => {
          alert("something to be wrong!!!");
        });
  }

  //edit using emit
  @Output() editEmit = new EventEmitter();
  //transfer data from component to template
  editUsingEmit(id: number){
    this.employeeService.getEmployee(id)
      .subscribe((data) => {
        console.log("ettited:::");
        console.log(data); 
        this.editEmit.emit(data);
      },
        (error) => {
          alert("something to be wrong!!!");
        });
  }

}
