import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../../services/employee.service';
import { SubjectMessageService } from '../../../services/subject-message.service'
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  id: number = null;
  name: string = '';
  address: string = '';
  contact: number = null;
  imageUrl: string;
  updateFlag: boolean = false;

  constructor(private employeeService: EmployeeService,
    private subMsg: SubjectMessageService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    //this.editData();

    // let paramId = this.activatedRoute.snapshot.paramMap.get("id");
    // if (paramId) {
    //   this.editUsingRouterLink(Number(paramId));
    // }
    let editCall = this.activatedRoute.paramMap.subscribe(params => {
      let paramId = Number(params.get('id'));
      if (paramId) {
        this.editUsingRouterLink(paramId);
      }
    });
  }

  addEmployee(): void {
    const data = {
      id: this.id,
      name: this.name,
      address: this.address,
      contact: this.contact,
      imageUrl: this.imageUrl
    }
    /* this.employeeService.addEmployee(data)
      .subscribe(() => {
        this.subMsg.setMessage({ msg: 'Successfull' });
        this.clearForm();
      },
        (error) => {
          alert("something to be wrong!!!");
        }); */

    console.log("id: " + this.id);
    if (this.id) {
      console.log("upateExisting");
      this.upateExisting(data);
    } else {
      console.log("addNew");
      this.addNew(data);
    }
  }

  addNew(data): void {
    this.employeeService.addEmployee(data)
      .subscribe(() => {
        this.subMsg.setMessage({ msg: 'Successfull' });
        this.clearForm();
      },
        (error) => {
          alert("something to be wrong!!!");
        });
  }
  upateExisting(data): void {
    this.employeeService.updateEmployee(data)
      .subscribe(() => {
        this.subMsg.setMessage({ msg: 'Successfull' });
        this.clearForm();
      },
        (error) => {
          alert("something to be wrong!!!");
        });
  }

  clearForm(): void {
    console.log("clering From");
    this.id = null;
    this.name = '';
    this.address = '';
    this.contact = null;
    this.imageUrl = '';
    this.updateFlag = false;
  }

  fillData(data): void {
    this.id = data.id,
      this.name = data.name,
      this.address = data.address,
      this.contact = data.contact,
      this.imageUrl = data.imageUrl
  }
  //for edit case
  editData() {
    this.subMsg.getData().subscribe(
      (data) => {
        console.log("::::: from add-employee:::::");
        console.log(data);
        this.fillData(data);
        this.updateFlag = true;
      })
  }

  editUsingRouterLink(id: number) {
    this.employeeService.getEmployee(id).subscribe((data) => {
      console.log(data);
      this.fillData(data);
      this.updateFlag = true;
    },
      (error) => {
        alert("something to be wrong!!!");
      });
  }

  fillEmitedData(data) {
    console.log(":::Emited Data:::");
    console.log(data);
  }

}
