import { Component, OnInit, Input } from '@angular/core';
import { Employee } from 'src/app/model/employee';

@Component({
  selector: 'app-emplist',
  templateUrl: './emplist.component.html',
  styleUrls: ['./emplist.component.css']
})
export class EmplistComponent implements OnInit {

// interpolation
  //@Input() empName:string;

//property binding
  @Input() emp:Employee;

  constructor() { }

  ngOnInit(): void {
  }

}
