import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor(private router: Router) { }
  model: any = {};
  ngOnInit(): void {
  }

  login() {
    console.log(this.model);
    if (this.model.userName == "admin" && this.model.password == "1234") {
      this.router.navigate(['/profile']);
    }
    else {
      alert("wrong credential");
    }
  }
}
