import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SubjectMessageService {

  subject = new Subject();

  constructor() { }

  setMessage(message : any){
    this.subject.next(message);
  }
  getMessage():Observable<any>{
    return this.subject.asObservable();
  }

  setData(data: any)
  {
    this.subject.next(data);
  }
  getData():Observable<any>{
    return this.subject.asObservable();
  }
}
