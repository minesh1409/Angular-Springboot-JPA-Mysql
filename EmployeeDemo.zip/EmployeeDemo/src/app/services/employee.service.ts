import { Injectable, Output, EventEmitter } from '@angular/core';
import { Employee } from '../model/employee';
import { baseUrl } from '../configuration/api'
import { HttpClient } from '@angular/common/http'
import { from, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  
  apiUrl = baseUrl + '/api';

  //  comment for implement api
  /* empList: Employee[] = [
    new Employee(1, 'jhon', 'cassel break, winterfall', 9900878999, new Date(), ''),
    new Employee(2, 'arya', 'North, winterfall', 9900878988, new Date(), ''),
    new Employee(3, 'theon', 'unknown world', 9900878977, new Date(), '')
  ] */

  constructor(private http: HttpClient) { }
  //  comment for implement api
  /* getEmployeeList():Employee[]{
    return this.empList
  } 

  addEmployee(data) {
    const employeeData = new Employee(
      data.id,
      data.name,
      data.address,
      data.contact,
      data.imageUrl,
      data.createdAt,
      data.updatedAt);
    this.empList.push(employeeData);
  }*/

  //implement api
  getEmployeeList(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.apiUrl + '/employees');
  }

  addEmployee(data): Observable<Employee> {
    console.log(data);
    return this.http.post<Employee>(this.apiUrl + '/employees', data);
  }

  getEmployee(id: number): Observable<Employee> {
    console.log("getting : "+id);
    return this.http.get<Employee>(this.apiUrl + '/employees/' + id);
  }
  updateEmployee(data):Observable<Employee>{
    console.log("updating : "+data.id);
    console.log(data);
    return this.http.put<Employee>(this.apiUrl + '/employees/' + data.id,data);
  }
  removeEmployee(id: number): Observable<any> {
    console.log("removing : "+id);
    return this.http.delete(this.apiUrl + '/employees/' + id);
  }
  //alternate way not good
  /* getEmployeeList1(){
    return this.http.get(this.apiUrl + '/employees');
  } 
  addEmployee(data) {
     return this.http.post(this.apiUrl+'/employees',data);
  }*/

}
