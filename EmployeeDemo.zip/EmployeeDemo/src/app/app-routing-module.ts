import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { ProfileComponent } from './components/profile/profile.component';
import { EditProfileComponent } from './components/profile/edit-profile/edit-profile.component';
import { EmployeeListComponent } from './components/empoloyees/employee-list/employee-list.component';
import { AddEmployeeComponent } from './components/empoloyees/add-employee/add-employee.component';
import { PagenotfoundComponent } from './components/shared/pagenotfound/pagenotfound.component'

const routes: Routes = [
    { path: 'register', component: RegisterComponent },
    { path: 'login', component: LoginComponent },
    {
        path: 'profile', component: ProfileComponent,
        children: [
            { path: 'edit', component: EditProfileComponent },
            { path: 'employee/add', component: AddEmployeeComponent },
            { path: 'employee/list', component: EmployeeListComponent },
            { path: 'employee/edit/:id', component: AddEmployeeComponent }
        ]
    },
    { path: 'add', component: ProfileComponent },
    { path: 'list', component: ProfileComponent },
    { path: '**', component: PagenotfoundComponent }
]

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [
        RouterModule
    ]
})
export class AppRoutingModule {

}