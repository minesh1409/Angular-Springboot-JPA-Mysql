export class Employee {
    id: number;
    name: string;
    address: string;
    contact: number;
    imageUrl: string;
    createdAt: Date;
    updatedAt: Date;

    constructor(id: number,
        name: string,
        address: string,
        contact: number,
        imageUrl: string,
        createdAt: Date,
        updatedAt: Date) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.contact = contact;
        this.imageUrl = imageUrl;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
}
