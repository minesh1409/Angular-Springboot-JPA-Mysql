import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/shared/header/header.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { NavbarComponent } from './components/shared/navbar/navbar.component';
import { ProfileComponent } from './components/profile/profile.component';
import { EmployeeListComponent } from './components/empoloyees/employee-list/employee-list.component';
import { EmplistComponent } from './components/empoloyees/emplist/emplist.component';
import { AddEmployeeComponent } from './components/empoloyees/add-employee/add-employee.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';

//manual added
import {FormsModule , ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
//for implement router manually
//move to seperate module so commented it
//import{RouterModule, Routes} from '@angular/router';
//add below for seperate module of route
import {AppRoutingModule} from './app-routing-module';
import { EditProfileComponent } from './components/profile/edit-profile/edit-profile.component';
import {EmployeeDetailComponent} from './components/empoloyees/employee-list/employee-detail/employee-detail.component';

//declare routes
//move to seperate module so commented it
// const routes:Routes=[
//   {path:'register', component: RegisterComponent},
//   {path:'login', component: LoginComponent},
//   {path:'profile', component: ProfileComponent}
// ]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavbarComponent,
    ProfileComponent,
    EmployeeListComponent,
    EmplistComponent,
    AddEmployeeComponent,
    LoginComponent,
    RegisterComponent,
    EditProfileComponent,
    EmployeeDetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    //RouterModule.forRoot(routes)
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
